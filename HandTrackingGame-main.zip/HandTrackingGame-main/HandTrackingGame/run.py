import cv2
import mediapipe as mp
import math
import keyboard
import time

mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles
mp_hands = mp.solutions.hands

# Khởi tạo webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("Không thể mở webcam.")
    exit()

# Giảm độ phân giải để tăng hiệu suất (tùy chọn)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

with mp_hands.Hands(
    model_complexity=0,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5) as hands:
  while cap.isOpened():
    success, image = cap.read()
    if not success:
      print("Ignoring empty camera frame.")
      continue

    try:
      # Đo thời gian xử lý khung hình
      start_time = time.time()

      image.flags.writeable = False
      image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
      results = hands.process(image)

      image.flags.writeable = True
      image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
      height, width, _ = image.shape
      
      if results.multi_hand_landmarks and len(results.multi_hand_landmarks) == 2:
        hand_centers = []
        for hand_landmarks in results.multi_hand_landmarks:
          hand_centers.append(
            [int(hand_landmarks.landmark[9].x * width), int(hand_landmarks.landmark[9].y * height)])
          mp_drawing.draw_landmarks(
              image,
              hand_landmarks,
              mp_hands.HAND_CONNECTIONS,
              mp_drawing_styles.get_default_hand_landmarks_style(),
              mp_drawing_styles.get_default_hand_connections_style())
        
        # Vẽ đường nối giữa hai tay
        cv2.line(image, (hand_centers[0][0], hand_centers[0][1]), 
                (hand_centers[1][0], hand_centers[1][1]), (0, 255, 0), 5)
        
        # Tính tâm và bán kính
        center_x = (hand_centers[0][0] + hand_centers[1][0]) // 2
        center_y = (hand_centers[0][1] + hand_centers[1][1]) // 2 
        radius = int(math.sqrt((hand_centers[0][0] - hand_centers[1][0]) ** 2 + 
                              (hand_centers[0][1] - hand_centers[1][1]) ** 2) / 2)
        
        # Vẽ vòng tròn
        cv2.circle(image, (center_x, center_y), radius, (0, 255, 0), 5)
        
        # Tính góc xoay (độ) so với trục ngang
        dx = hand_centers[1][0] - hand_centers[0][0]
        dy = hand_centers[1][1] - hand_centers[0][1]
        angle = math.degrees(math.atan2(dy, dx))
        
        # Tính tọa độ điểm cuối của đường bán kính (đi xuống dưới)
        radius_end_x = center_x + int(radius * math.cos(math.radians(angle - 90)))
        radius_end_y = center_y + int(radius * math.sin(math.radians(angle - 90)))
        
        # Vẽ đường bán kính
        cv2.line(image, (center_x, center_y), (radius_end_x, radius_end_y), (0, 255, 0), 5)
        
        # Luôn nhấn phím 'w' khi phát hiện hai tay (tiến)
        keyboard.press('w')
        
        # Xác định hướng xoay với vùng trung lập: 170° đến -170°
        if 0 <= angle <= 170:  # Từ 0° đến 170°: Xoay phải (W + D)
          keyboard.release('a')
          keyboard.press('d')
          cv2.putText(image, "Turning Right (W + D)", (10, 30), 
                     cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        elif -170 <= angle <= 0:  # Từ -170° đến 0°: Xoay trái (W + A)
          keyboard.release('d')
          keyboard.press('a')
          cv2.putText(image, "Turning Left (W + A)", (10, 30), 
                     cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        else:  # Từ 170° đến 180° và -180° đến -170°: Đi thẳng (W)
          keyboard.release('a')
          keyboard.release('d')
          cv2.putText(image, "Straight (W)", (10, 30), 
                     cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        
        # Hiển thị góc để kiểm tra
        cv2.putText(image, f"Angle: {int(angle)}", (10, 60), 
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)

      else:
        # Nếu không phát hiện hai tay, thả tất cả phím
        keyboard.release('w')
        keyboard.release('a')
        keyboard.release('d')
        cv2.putText(image, "No hands detected", (10, 30), 
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

      # Flip image SAU khi vẽ text
      image = cv2.flip(image, 1)
      cv2.imshow('MediaPipe Hands', image)

      # Tăng thời gian chờ để giảm tải (10ms)
      key = cv2.waitKey(10) & 0xFF
      if key == 27:  # Nhấn ESC để thoát
        break

    except Exception as e:
      print(f"Lỗi: {e}")
      break

cap.release()
cv2.destroyAllWindows()
keyboard.release('w')
keyboard.release('a')
keyboard.release('d')